/*
 * main.cpp
 *
 *  Created on: Jan 25, 2016
 *      Author: rahulpaul
 */

#include <cv.h>
#include <highgui.h>
#include <cxcore.h>
#include <fstream>
#include <iostream>
#include <cmath>

#define PI 3.142857

using namespace cv;
using namespace std;

//Data Structure for storing Camera Location, lense location, axis direction, vertex location
Mat camera_location = Mat(3,1,DataType<float>::type);
Mat axis_direction = Mat(3,1,DataType<float>::type);
Mat lense_location = Mat(3,1,DataType<float>::type);

Mat poly_shape_vertex;

vector<Mat> poly_shape_vertices;//storing vertices of the poly-hedral

map<float,Mat> polyVertex_no_Location_Map;
map<float,Mat> vertex_no_image_plane_location_Map;

//Image Pofloats in Image Plane
Mat image_plane_vertex_location = Mat(2,1,DataType<float>::type);
vector<Mat> image_plane_vertex_locations;

//Data Structure for storing connected vertex pair
Mat poly_shape_conn_vertex;
vector<Mat> poly_shape_conn_vertices;


float focal_length = 0;
float total_edges = 0;
float total_vertices = 0;

float distance_camera_x,distance_camera_y,distance_camera_z;

float distance_vertex_x,distance_vertex_y,distance_vertex_z;

float rotated_vertex_alongZ_x, rotated_vertex_alongZ_y,rotated_vertex_alongZ_z; //pan along Z

float rotated_vertex_alongX_x, rotated_vertex_alongX_y,rotated_vertex_alongX_z; //tilt along X

float trans_param_w;

float theta_angle_pan_mag;

float theta_angle_pan;

float theta_angle_tilt_mag;

float theta_angle_tilt;




//method prototypes
void read_config_file(char * fileName);
void calculate_lense_location();
void calculate_params_for_each_object_vertex();
void draw_the_projected_shape();



int main( int argc, char** argv )
{

	//read the configuration file
	char * config_fileName = argv[1];

	/*cout << "Provide the data file path with name \n";
	cin >> config_fileName;*/

	read_config_file(config_fileName);

	calculate_params_for_each_object_vertex();

	draw_the_projected_shape();

	return(0);

}

void calculate_params_for_each_object_vertex()
{
	// calculating the angle here.
	distance_camera_x = axis_direction.at<float>(0,0) - camera_location.at<float>(0,0);;
	distance_camera_y = axis_direction.at<float>(1,0) - camera_location.at<float>(1,0);
	distance_camera_z = axis_direction.at<float>(2,0) - camera_location.at<float>(2,0);

	theta_angle_pan_mag =  distance_camera_y /
								sqrt(distance_camera_x * distance_camera_x +
								distance_camera_y * distance_camera_y);

	theta_angle_pan = acos(theta_angle_pan_mag);

	theta_angle_pan = theta_angle_pan + PI; //since the measurement was clockwise


	theta_angle_tilt_mag =  distance_camera_z /
									sqrt(distance_camera_x * distance_camera_x +
									distance_camera_y * distance_camera_y      +
									distance_camera_z * distance_camera_z);


	theta_angle_tilt = acos(theta_angle_tilt_mag);//Angle already measured in Anti-Clockwise



	for(float vertex_counter = 0; vertex_counter < total_vertices; vertex_counter ++)
	{
		image_plane_vertex_location = Mat(2,1,DataType<float>::type);

		distance_vertex_x = poly_shape_vertices[vertex_counter].at<float>(0,0) - camera_location.at<float>(0,0);
		distance_vertex_y = poly_shape_vertices[vertex_counter].at<float>(1,0) - camera_location.at<float>(1,0);
		distance_vertex_z = poly_shape_vertices[vertex_counter].at<float>(2,0) - camera_location.at<float>(2,0);

		rotated_vertex_alongZ_x = (distance_vertex_x * cos(theta_angle_pan)) +
							(distance_vertex_y * sin(theta_angle_pan));
		rotated_vertex_alongZ_y = (distance_vertex_x * cos(theta_angle_pan)) -
							(distance_vertex_y * sin(theta_angle_pan));
		rotated_vertex_alongZ_z = distance_vertex_z;


		rotated_vertex_alongX_x = rotated_vertex_alongZ_x;

		rotated_vertex_alongX_y = (rotated_vertex_alongZ_y * cos(theta_angle_tilt)) +
							(rotated_vertex_alongZ_z * sin(theta_angle_tilt));

		rotated_vertex_alongX_z = (rotated_vertex_alongZ_z* cos(theta_angle_tilt)) -
							(rotated_vertex_alongZ_y * sin(theta_angle_tilt));

		trans_param_w = 1 - (rotated_vertex_alongX_z / focal_length);

		rotated_vertex_alongX_x  = rotated_vertex_alongX_x / trans_param_w;
		rotated_vertex_alongX_y  = rotated_vertex_alongX_y / trans_param_w;


		//scale to 256 X 256 pixels
		image_plane_vertex_location.at<float>(0,0) = (rotated_vertex_alongX_x * 256)+128;
		image_plane_vertex_location.at<float>(1,0) = (rotated_vertex_alongX_y * 256)+128;

		image_plane_vertex_locations.push_back(image_plane_vertex_location);
	}
}

void draw_the_projected_shape()
{

	Mat final_image = Mat::zeros( 255, 255, CV_8UC3 );


	for(float edge_counter = 0; edge_counter < total_edges; edge_counter++)
	{
		float vertex1 = poly_shape_conn_vertices[edge_counter].at<float>(0,0);
		float vertex2 = poly_shape_conn_vertices[edge_counter].at<float>(1,0);

		Mat vertex1_mat = image_plane_vertex_locations[vertex1 -1];
		Mat vertex2_mat = image_plane_vertex_locations[vertex2 - 1];



		// Draw a line
				  line( final_image, Point(ceil(vertex1_mat.at<float>(0,0)),
						  	  	  	  	  ceil(vertex1_mat.at<float>(1,0))),
						  Point(ceil(vertex2_mat.at<float>(0,0)),
								  ceil(vertex2_mat.at<float>(1,0))),
						  Scalar( 255, 255, 255 ),  2, 8 );
	}

	cv::imshow("Image Generic Projection",final_image);
	cv::imwrite("Generic_Projection_Output.jpg",final_image);
	cv::waitKey(0);

}



void read_config_file(char * config_fileName)
{
	fstream config_fstream;
	config_fstream.open(config_fileName, fstream::in);

	//extract camera location from the config file first
	float currentValue;
	config_fstream >> currentValue;
	camera_location.at<float>(0, 0) = currentValue;

	config_fstream >> currentValue;
	camera_location.at<float>(1, 0) = currentValue;

	config_fstream >> currentValue;
	camera_location.at<float>(2, 0) = currentValue;


	//clean the temporary variable
	currentValue = 0;

	//extract direction location in which camera is looking
	config_fstream >> currentValue;
	axis_direction.at<float>(0, 0) = currentValue;

	config_fstream >> currentValue;
	axis_direction.at<float>(1, 0) = currentValue;

	config_fstream >> currentValue;
	axis_direction.at<float>(2, 0) = currentValue;

	//extract the focal length
	config_fstream >> focal_length;

	//extract the edges
	config_fstream >> total_edges;

	//extract the vertices
	config_fstream >> total_vertices;

	//Read all the vertices
	for(float vertex_counter = 0; vertex_counter < total_vertices; vertex_counter++ )
	{
		//clean the temporary variable
		currentValue = 0;
		poly_shape_vertex = Mat(3,1,DataType<float>::type);

		//extract co-ordinate for each polhedral vertices
		//000
		config_fstream >> currentValue;
		poly_shape_vertex.at<float>(0, 0) = currentValue;

		config_fstream >> currentValue;
		poly_shape_vertex.at<float>(1, 0) = currentValue;

		config_fstream >> currentValue;
		poly_shape_vertex.at<float>(2, 0) = currentValue;

		poly_shape_vertices.push_back(poly_shape_vertex);

		polyVertex_no_Location_Map[vertex_counter + 1] = poly_shape_vertex;
	}

	//read all the pairs of connected vertices

	for(float edge_counter = 0; edge_counter < total_edges; edge_counter++ )
	{
		//clean the temporary variable
		currentValue = 0;
		poly_shape_conn_vertex = Mat(2,1,DataType<float>::type);

		//first pair
		config_fstream >> currentValue;
		poly_shape_conn_vertex.at<float>(0, 0) = currentValue;

		config_fstream >> currentValue;
		poly_shape_conn_vertex.at<float>(1, 0) = currentValue;

		poly_shape_conn_vertices.push_back(poly_shape_conn_vertex);
	}
}







